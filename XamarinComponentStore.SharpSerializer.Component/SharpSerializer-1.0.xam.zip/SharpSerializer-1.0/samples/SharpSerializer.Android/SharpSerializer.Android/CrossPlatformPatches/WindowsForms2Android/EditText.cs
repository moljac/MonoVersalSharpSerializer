using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CrossPlatformPatches.WindowsForms2Android 
{
	public partial class EditText //: Android.Widget.EditText
	{
	}
}
